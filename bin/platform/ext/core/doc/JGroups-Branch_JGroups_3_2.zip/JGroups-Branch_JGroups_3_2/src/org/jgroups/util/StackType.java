package org.jgroups.util;

/**
 * @author Bela Ban
 */
public enum StackType {
    IPv4, IPv6, Unknown
}
